/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package realestate;
import java.time.LocalDate;
/**
 *
 * @author juhaszs.20d
 */

public class Ad {
    private int id;
    private int rooms;
    private String latlong;
    private int floors;
    private int area;
    private boolean freeOfCharge;
    private String imageUrl;
    private String createAt;
    private Seller seller;
    private Category category;

    public Ad(int id, int rooms, String latlong, int floors, int area, boolean freeOfCharge,
              String imageUrl, String createAt, Seller seller, Category category) {
        this.id = id;
        this.rooms = rooms;
        this.latlong = latlong;
        this.floors = floors;
        this.area = area;
        this.freeOfCharge = freeOfCharge;
        this.imageUrl = imageUrl;
        this.createAt = createAt;
        this.seller = seller;
        this.category = category;
    }

    public double distanceTo(String targetLatLong) {
        String[] coords1 = latlong.split(",");
        String[] coords2 = targetLatLong.split(",");
        
        double lat1 = Double.parseDouble(coords1[0]);
        double lon1 = Double.parseDouble(coords1[1]);
        
        double lat2 = Double.parseDouble(coords2[0]);
        double lon2 = Double.parseDouble(coords2[1]);

        return Math.sqrt(Math.pow(lat2 - lat1, 2) + Math.pow(lon2 - lon1, 2));
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getRooms() {
        return rooms;
    }

    public void setRooms(int rooms) {
        this.rooms = rooms;
    }

    public String getLatlong() {
        return latlong;
    }

    public void setLatlong(String latlong) {
        this.latlong = latlong;
    }

    public int getFloors() {
        return floors;
    }

    public void setFloors(int floors) {
        this.floors = floors;
    }

    public int getArea() {
        return area;
    }

    public void setArea(int area) {
        this.area = area;
    }

    public boolean isFreeOfCharge() {
        return freeOfCharge;
    }

    public void setFreeOfCharge(boolean freeOfCharge) {
        this.freeOfCharge = freeOfCharge;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getCreateAt() {
        return createAt;
    }

    public void setCreateAt(String createAt) {
        this.createAt = createAt;
    }

    public Seller getSeller() {
        return seller;
    }

    public void setSeller(Seller seller) {
        this.seller = seller;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    
}

    

