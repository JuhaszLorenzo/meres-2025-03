/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package realestate;

import java.io.BufferedReader;
import java.io.FileReader;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author juhaszs.20d
 */


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CSVLoader {

    public static List<Ad> loadFromCsv(String fileName) throws IOException {
        List<Ad> ads = new ArrayList<>();
        
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;

            // Az első sor (header) átugrása
            br.readLine();

            while ((line = br.readLine()) != null) {
                String[] fields = line.split(";");

                int id = Integer.parseInt(fields[0]);
                int rooms = Integer.parseInt(fields[1]);
                String latlong = fields[2];
                int floors = Integer.parseInt(fields[3]);
                int area = Integer.parseInt(fields[4]);
                boolean freeOfCharge = fields[6].equals("1");
                String imageUrl = fields[7];
                String createAt = fields[8];

                Seller seller = new Seller(Integer.parseInt(fields[9]), fields[10], fields[11]);
                Category category = new Category(Integer.parseInt(fields[12]), fields[13]);

                ads.add(new Ad(id, rooms, latlong, floors, area, freeOfCharge,
                               imageUrl, createAt, seller, category));
            }
        }
        
        return ads;
    }
}