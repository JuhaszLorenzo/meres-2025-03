/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package realestate;
import java.io.IOException;
import java.util.List;
/**
 *
 * @author juhaszs.20d
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
try {
            // CSV fájl beolvasása
            List<Ad> ads = CSVLoader.loadFromCsv("realestates.csv");

            // 6. feladat: Földszinti ingatlanok átlagos alapterülete
            System.out.println("1. Földszinti ingatlanok átlagos alapterülete: " 
                + String.format("%.2f", calculateAverageArea(ads)) + " m2");

            // 8. feladat: Legközelebbi tehermentes ingatlan keresése
            Ad closestProperty = findClosestFreeProperty(ads, "47.4164220114023,19.066342425796986");
            if (closestProperty != null) {
                System.out.println("2. Mesevár óvodához légvonalban legközelebbi tehermentes ingatlan adatai:");
                System.out.println("    Eladó neve: " + closestProperty.getSeller().getName());
                System.out.println("    Eladó telefonja: " + closestProperty.getSeller().getPhone());
                System.out.println("    Alapterület: " + closestProperty.getArea());
                System.out.println("    Szobák száma: " + closestProperty.getRooms());
            } else {
                System.out.println("Nincs tehermentes ingatlan.");
            }
        } catch (IOException e) {
            System.err.println("Hiba történt a fájl beolvasása során: " + e.getMessage());
        }
    }

    public static double calculateAverageArea(List<Ad> ads) {
        return ads.stream()
                  .filter(ad -> ad.getFloors() == 0)
                  .mapToInt(Ad::getArea)
                  .average()
                  .orElse(0.0);
    }

    public static Ad findClosestFreeProperty(List<Ad> ads, String targetLatLong) {
        return ads.stream()
                  .filter(Ad::isFreeOfCharge)
                  .min((ad1, ad2) -> Double.compare(
                      ad1.distanceTo(targetLatLong), ad2.distanceTo(targetLatLong)))
                  .orElse(null);
    }
}